import React from 'react'
import { useState } from 'react'

export const QrCode = () => {
    const [img,setImage]= useState("https://api.qrserver.com/v1/create-qr-code/?size=${sizedata}X${sizedata}&data=HI")
    const [loading,setLoading]= useState(false)
    const [qrdata,setQrdata] = useState()
    const [sizedata,setSize]= useState(150)

     async function generateQr() {
        setLoading(true)
        try{
            const url=`https://api.qrserver.com/v1/create-qr-code/?size=${sizedata}X${sizedata}&data=${encodeURIComponent(qrdata)}`;
            setImage(url)
        }
        catch (error){
            console.log("Error Occured While Generate..",error)  
        }
        finally{
            setLoading(false)
        }
    }

    async function downloadQr()
    {
        fetch(img)
        .then((response)=>response.blob())
        .then((blob)=>{
            const link = document.createElement("a")
            link.href = URL.createObjectURL(blob)
            link.download = "qrCode.png"
            document.body.appendChild(link);
            link.click()
            document.body.removeChild(link)
        })
    }
  return (

    <div className='container'>

        <h1>QR CODE GENERATOR</h1>
        { loading && <p>Please wait.....</p>}
        {img && <img src={img} alt=""  className='qr-image'/>}
        <div className='input-box'>
        <label htmlFor="dataInput" className='label'>Data for QR code:</label>
        <input type="text" placeholder='Enter data for QR code' value={qrdata} onChange={(e)=>setQrdata (e.target.value)}/>
        <label htmlFor="sizeInput" className='label'>Image Size (eg:150)</label>
        <input type="text" placeholder='Enter Image size' value={sizedata} onChange={(e)=>setSize (e.target.value)} />
        <button className='generate-btn'onClick={generateQr}>Generate QR Code</button>
        <button className='download-btn' onClick={downloadQr}> Download QR Code</button>
        </div>
    </div>
  ) 
}
